'use strict';

// 六项指标只在此数组定义；HTML 中没有重复卡片。数据为课程演示数据。
const metrics = [
  { id: 'revenue', label: '总营收', format: 'currency', icon: 'revenue', values: [128650, 532480, 1582640], changes: [12.8, 16.2, 21.5], trend: [12, 20, 16, 27, 23, 34, 40] },
  { id: 'orders', label: '成交订单', format: 'integer', icon: 'orders', values: [1842, 7624, 22685], changes: [8.2, 11.6, 18.3], trend: [14, 10, 20, 18, 25, 30, 34] },
  { id: 'users', label: '活跃用户', format: 'integer', icon: 'users', values: [24680, 98640, 284120], changes: [18.6, 14.3, 24.7], trend: [10, 16, 13, 24, 29, 26, 40] },
  { id: 'conversion', label: '转化率', format: 'percent', icon: 'conversion', values: [3.86, 4.12, 4.35], changes: [0.42, 0.36, 0.58], points: true, trend: [13, 19, 15, 24, 20, 28, 32] },
  { id: 'average', label: '客单价', format: 'currencyDecimal', icon: 'average', values: [69.84, 69.84, 69.76], changes: [4.3, 4.1, 2.7], trend: [18, 16, 23, 20, 25, 29, 34] },
  { id: 'refund', label: '退款率', format: 'percent', icon: 'refund', values: [1.24, 1.18, 1.09], changes: [-0.18, -0.12, -0.21], points: true, lowerBetter: true, trend: [35, 30, 33, 24, 27, 18, 14] }
];
const periods = {
  week: { index: 0, name: '近 7 天', compare: '前 7 天', labels: ['10/17', '10/18', '10/19', '10/20', '10/21', '10/22', '10/23'], revenue: [14200, 16400, 15850, 18700, 19600, 20900, 23000], channels: [42, 28, 18, 12], range: '2026.10.17 — 2026.10.23' },
  month: { index: 1, name: '近 30 天', compare: '前 30 天', labels: ['第1段', '第2段', '第3段', '第4段', '第5段', '第6段', '第7段'], revenue: [62400, 68500, 72300, 76100, 79800, 83380, 90000], channels: [39, 31, 19, 11], range: '2026.09.24 — 2026.10.23' },
  quarter: { index: 2, name: '近 90 天', compare: '前 90 天', labels: ['第1段', '第2段', '第3段', '第4段', '第5段', '第6段', '第7段'], revenue: [186400, 205000, 216800, 227400, 236000, 247040, 264000], channels: [37, 33, 20, 10], range: '2026.07.26 — 2026.10.23' }
};
const iconPaths = {
  revenue: '<path d="M12 3v18m4-14h-6a3 3 0 0 0 0 6h4a3 3 0 0 1 0 6H7"/>',
  orders: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 3v3m6-3v3M9 11h6m-6 5h6"/>',
  users: '<circle cx="9" cy="8" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3m2-16a3 3 0 0 1 0 6m1 4a5 5 0 0 1 3 5"/>',
  conversion: '<path d="M4 19 20 3m-6 0h6v6"/><circle cx="6" cy="6" r="3"/><circle cx="18" cy="18" r="3"/>',
  average: '<path d="M3 7h18v13H3zM3 7l3-4h12l3 4M8 11a4 4 0 0 0 8 0"/>',
  refund: '<path d="M4 10a8 8 0 1 1 1 8M4 4v6h6M12 8v8m-2-2 2 2 2-2"/>'
};
const numberFormat = new Intl.NumberFormat('zh-CN');
let currentPeriod = 'week';
function formatValue(metric, value) {
  if (metric.format === 'percent') return value.toFixed(2) + '%';
  if (metric.format === 'currencyDecimal') return '¥' + value.toFixed(2);
  return (metric.format === 'currency' ? '¥' : '') + numberFormat.format(value);
}
function renderDashboard(key) {
  currentPeriod = key;
  const period = periods[key];
  document.querySelectorAll('[data-period]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.period === key)));
  document.getElementById('period-description').textContent = period.range + ' · 与' + period.compare + '对比（固定演示区间）';
  document.getElementById('metrics').innerHTML = metrics.map(metric => {
    const change = metric.changes[period.index];
    const good = metric.lowerBetter ? change <= 0 : change >= 0;
    const points = metric.trend.map((value, index) => `${index * 30},${43 - value + period.index * (index % 2 ? 2 : -2)}`).join(' ');
    return `<article class="metric-card" aria-labelledby="title-${metric.id}">
      <div class="metric-header"><h2 id="title-${metric.id}">${metric.label}</h2><span class="metric-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[metric.icon]}</svg></span></div>
      <p class="metric-value">${formatValue(metric, metric.values[period.index])}</p>
      <div class="metric-bottom"><span class="metric-change ${good ? '' : 'negative'}">${change >= 0 ? '↑' : '↓'} ${Math.abs(change)}${metric.points ? ' pp' : '%'}</span><span>较${period.compare}${metric.points ? ' · 百分点' : ''}</span></div>
      <svg class="sparkline" width="180" height="36" viewBox="0 0 180 44" preserveAspectRatio="none" aria-hidden="true"><polyline points="${points}" fill="none" stroke="currentColor" stroke-width="2" vector-effect="non-scaling-stroke"/></svg>
    </article>`;
  }).join('');
  document.getElementById('revenue-total').textContent = formatValue(metrics[0], metrics[0].values[period.index]);
  document.getElementById('revenue-change').textContent = '↑ ' + metrics[0].changes[period.index] + '% 较' + period.compare;
  const max = Math.max(...period.revenue);
  document.getElementById('revenue-chart').innerHTML = period.revenue.map((value, index) => `<div class="bar-item" role="img" aria-label="${period.labels[index]}，营收${value}元"><div class="bar-track" title="${numberFormat.format(value)} 元"><div class="bar" style="height:${value / max * 100}%"></div></div><p class="bar-label">${period.labels[index]}</p></div>`).join('');
  document.getElementById('channel-list').innerHTML = ['自然搜索', '直接访问', '社交媒体', '其他渠道'].map((name, index) => `<div class="channel"><div class="channel-heading"><span>${name}</span><strong>${period.channels[index]}%</strong></div><div class="channel-track" aria-hidden="true"><div class="channel-fill" style="width:${period.channels[index]}%;opacity:${1 - index * 0.17}"></div></div></div>`).join('');
  document.getElementById('insight-text').textContent = `自然搜索贡献了 ${period.channels[0]}% 的访问量，是本期主要流量来源。可持续关注搜索渠道的内容表现。`;
  document.getElementById('status').textContent = '已切换为' + period.name + '，六项指标和图表已更新。';
}
function setTheme(theme) {
  document.documentElement.dataset.theme = theme;
  const dark = theme === 'dark';
  const label = dark ? '浅色模式' : '深色模式';
  document.getElementById('theme-label').textContent = label;
  document.getElementById('theme-toggle').setAttribute('aria-label', '切换到' + label);
  document.getElementById('theme-toggle').setAttribute('aria-pressed', String(dark));
  try { localStorage.setItem('pulse-theme', theme); } catch { /* 禁用存储时仍可正常切换。 */ }
}
let initialTheme = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
try { const saved = localStorage.getItem('pulse-theme'); if (['light', 'dark'].includes(saved)) initialTheme = saved; } catch { /* 使用系统偏好。 */ }
setTheme(initialTheme);
document.getElementById('theme-toggle').addEventListener('click', () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));
document.querySelectorAll('[data-period]').forEach(button => button.addEventListener('click', () => renderDashboard(button.dataset.period)));
document.getElementById('export-button').addEventListener('click', () => {
  const period = periods[currentPeriod];
  const rows = [['统计周期', '指标', '数值', '较上期变化', '变化单位'], ...metrics.map(metric => [period.name, metric.label, metric.values[period.index], metric.changes[period.index], metric.points ? '百分点' : '%'])];
  const csv = '\uFEFF' + rows.map(row => row.map(value => '"' + String(value).replaceAll('"', '""') + '"').join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
  const link = document.createElement('a');
  link.href = url; link.download = 'pulse-' + currentPeriod + '.csv'; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  document.getElementById('status').textContent = '已导出' + period.name + '的六项指标。';
});
renderDashboard(currentPeriod);

// 同页视图导航：切换可见内容，而不仅仅跳到页面底部锚点。
const dashboardViews = {
  overview: { title: '经营数据总览', subtitle: '看见业务的每一步增长。', breadcrumb: '数据总览' },
  trend: { title: '营收趋势', subtitle: '查看当前统计周期的营收变化。', breadcrumb: '营收趋势' },
  channels: { title: '渠道表现', subtitle: '比较自然搜索、直接访问和其他渠道的流量贡献。', breadcrumb: '渠道表现' }
};
function selectDashboardView(hash = window.location.hash) {
  const requested = hash.replace(/^#/, '');
  const view = Object.hasOwn(dashboardViews, requested) ? requested : 'overview';
  const content = dashboardViews[view];
  document.getElementById('metrics').hidden = view !== 'overview';
  document.getElementById('trend').hidden = view === 'channels';
  document.getElementById('channels').hidden = view === 'trend';
  document.getElementById('details').dataset.view = view;
  document.getElementById('page-title').textContent = content.title;
  document.getElementById('view-subtitle').textContent = content.subtitle;
  document.getElementById('view-breadcrumb').textContent = content.breadcrumb;
  document.querySelectorAll('.nav-link').forEach(link => {
    const active = link.getAttribute('href') === '#' + view;
    link.classList.toggle('active', active);
    if (active) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });
  document.getElementById('status').textContent = '已打开' + content.breadcrumb;
}
document.querySelectorAll('.nav-link').forEach(link => link.addEventListener('click', event => {
  event.preventDefault();
  const hash = link.getAttribute('href');
  if (window.location.hash !== hash) window.location.hash = hash;
  selectDashboardView(hash);
  window.scrollTo({ top: 0, behavior: 'instant' });
  document.getElementById('page-title').focus({ preventScroll: true });
}));
window.addEventListener('hashchange', () => selectDashboardView());
selectDashboardView();
